//
//  ViewController.swift
//  virusView
//
//  Created by 2020-2 on 21/02/20.
//  Copyright © 2020 2020-2. All rights reserved.
//

import UIKit

//Debemos heredar de UITableViewController para hacer listas  y cosas más sofisticadas

class ViewController: UITableViewController{
 
    var pictures = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
    navigationController?.navigationBar.prefersLargeTitles=true
        
        title = "Virus Viewer"
        let fm = FileManager.default
                let path = Bundle.main.resourcePath!

        
        let items = try!fm.contentsOfDirectory(atPath: path)
        
        for item in items {
            if item.hasSuffix(".jpg"){
                pictures.append(item)
                
            }
        }
        
        print(pictures)
        
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //count para saber el tamaño del arreglo
        //pictures es el arreglo que ya habíamos hecho
        return pictures.count
    }

    //Para eficientar el uso de los datos en la celda
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Picture", for: indexPath)
        cell.textLabel?.text = pictures[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1. Tratatemo de encontrar y relacionar Detail
        
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Detail") as? DetailViewController {
            
            //2. Exito, ya tengo referencia al view Controller por medio del vc, asigna selectedImage al string que esta tocando el usuario
            
            vc.selectedImage = pictures[indexPath.row]
            
            // 3. Cambiar la vista
            
            navigationController?.pushViewController(vc, animated: true)
            
            
            
            
       }
    }
}


//
//  ViewController.swift
//  TrafficViewer
//
//  Created by 2020-2 on 13/03/20.
//  Copyright © 2020 2020-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
//Este archivo está relacionado automáticamente con la primera plantilla (la plantilla azul)
    @IBAction func
        unwindToBlue(unwindSegue: UIStoryboardSegue){
    
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
          segue.destination.navigationItem.title = textField.text
        
    }
    
    
    @IBAction func buttonSegue(_ sender: Any) {
        
        if(textField.text=="Hola"){
            performSegue(withIdentifier: "Pink", sender: nil)
        }
        
    }
    
}

